# Tiny C Compiler

## Build
```
make
```

## Test
```
make test
```

## Run

To create the ./a.out file for test file numbered "i"

```
make run<i>
```

## Execute

```
./a.out
```
