//this is a file to test our code

/* we will 
 * be using
 * multi-line comments
 */

extern int foo(int a, int b);

int main() {
  int IntVariable_01 = 55;
  float FloatVariable01 = 22., FloatVariable02 = .01, FloatVariable03 = 13.231, FloatVariable04 = 3e10;
  double DoubleVariable03 = .39e-3;
  char string[] = "This is a string literal example with a \n character!";
  char char_array[] = {'t', 'e', 's', 't'};
  IntVariable01 += 72;
  return 0;
}
